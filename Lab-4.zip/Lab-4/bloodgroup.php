<form action="#" method="POST">
	<fieldset>
		<legend>BLOOD GROUP</legend>
		<select name="bgroup" >
					
			<option value="A+" <?php if(isset($_POST['bgroup']) && $_POST['bgroup'] == "A+"){echo "selected";}?>>A+ </option>
			<option value="A-" <?php if(isset($_POST['bgroup']) && $_POST['bgroup'] == "A-"){echo "selected";}?>>A- </option>
			<option value="B+" <?php if(isset($_POST['bgroup']) && $_POST['bgroup'] == "B+"){echo "selected";}?>>B+ </option>
			<option value="B-" <?php if(isset($_POST['bgroup']) && $_POST['bgroup'] == "B-"){echo "selected";}?>>B- </option>
			<option value="O+" <?php if(isset($_POST['bgroup']) && $_POST['bgroup'] == "O+"){echo "selected";}?>>O+ </option>
			<option value="O-" <?php if(isset($_POST['bgroup']) && $_POST['bgroup'] == "O-"){echo "selected";}?>>O- </option>
			<option value="AB+" <?php if(isset($_POST['bgroup']) && $_POST['bgroup'] == "AB+"){echo "selected";}?>>AB+ </option>
			<option value="AB-" <?php if(isset($_POST['bgroup']) && $_POST['bgroup'] == "AB-"){echo "selected";}?>>AB- </option>
  
		</select>
		
		<br/><br/>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>