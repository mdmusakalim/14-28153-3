<?php
	
	if(isset($_POST['degree'])){
		echo $_POST['degree'];
	}
	
?>
<form action="#" method="POST"> 
	<fieldset>
		<legend>DEGREE</legend>
			<input type="checkbox" name="degree"  value="SSC">SSC
			<input type="checkbox" name="degree"  value="HSC">HSC
			<input type="checkbox" name="degree"  value="BSC">BSC
			<input type="checkbox" name="degree"  value="MSC">MSC
  
  <br><br>
<hr/>
		<input type="submit" name="submit" value="Submit" >
		
</fieldset>