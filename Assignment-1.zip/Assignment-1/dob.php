<?php error_reporting(0);?>
<form action="#" method="post">
	<fieldset>
		<legend>DOB</legend>
		
		dd
		<select name="dd">
			<option value="01" <?php if($_POST['dd'] == "01"){ echo "selected";} ?>>01</option>
			<option value="02" <?php if($_POST['dd'] == "02"){ echo "selected";} ?>>02</option>
			<option value="03" <?php if($_POST['dd'] == "03"){ echo "selected";} ?>>03</option>
			<option value="04" <?php if($_POST['dd'] == "04"){ echo "selected";} ?>>04</option>
			<option value="05" <?php if($_POST['dd'] == "05"){ echo "selected";} ?>>05</option>
			<option value="06" <?php if($_POST['dd'] == "06"){ echo "selected";} ?>>06</option>
			<option value="07" <?php if($_POST['dd'] == "07"){ echo "selected";} ?>>07</option>
			<option value="08" <?php if($_POST['dd'] == "08"){ echo "selected";} ?>>08</option>
			<option value="09" <?php if($_POST['dd'] == "09"){ echo "selected";} ?>>09</option>
			<option value="10" <?php if($_POST['dd'] == "10"){ echo "selected";} ?>>10</option>
		</select>
		mm
		<select name="mm">
			<option value="01" <?php if($_POST['mm'] == "01"){ echo "selected";} ?>>01</option>
			<option value="02" <?php if($_POST['mm'] == "02"){ echo "selected";} ?>>02</option>
			<option value="03" <?php if($_POST['mm'] == "03"){ echo "selected";} ?>>03</option>
			<option value="04" <?php if($_POST['mm'] == "04"){ echo "selected";} ?>>04</option>
			<option value="05" <?php if($_POST['mm'] == "05"){ echo "selected";} ?>>05</option>
			<option value="06" <?php if($_POST['mm'] == "06"){ echo "selected";} ?>>06</option>
			<option value="07" <?php if($_POST['mm'] == "07"){ echo "selected";} ?>>07</option>
			<option value="08" <?php if($_POST['mm'] == "08"){ echo "selected";} ?>>08</option>
			<option value="09" <?php if($_POST['mm'] == "09"){ echo "selected";} ?>>09</option>
			<option value="10" <?php if($_POST['mm'] == "10"){ echo "selected";} ?>>10</option>
			<option value="11" <?php if($_POST['mm'] == "11"){ echo "selected";} ?>>11</option>
			<option value="12" <?php if($_POST['mm'] == "12"){ echo "selected";} ?>>12</option>
		</select>
		yy
		<select name="yy">
			<option value="1991" <?php if($_POST['yy'] == "1991"){ echo "selected";} ?>>1991</option>
			<option value="1992" <?php if($_POST['yy'] == "1992"){ echo "selected";} ?>>1992</option>
			<option value="1993" <?php if($_POST['yy'] == "1993"){ echo "selected";} ?>>1993</option>
			<option value="1994" <?php if($_POST['yy'] == "1994"){ echo "selected";} ?>>1994</option>
			<option value="1995" <?php if($_POST['yy'] == "1995"){ echo "selected";} ?>>1995</option>
			<option value="1996" <?php if($_POST['yy'] == "1996"){ echo "selected";} ?>>1996</option>
			<option value="1997" <?php if($_POST['yy'] == "1997"){ echo "selected";} ?>>1997</option>
			<option value="1998" <?php if($_POST['yy'] == "1998"){ echo "selected";} ?>>1998</option>
			<option value="1999" <?php if($_POST['yy'] == "1999"){ echo "selected";} ?>>1999</option>
			<option value="2000" <?php if($_POST['yy'] == "2000"){ echo "selected";} ?>>2000</option>
		</select>
		<br/>
		
		<input type="submit" name="submit" value="Submit">
	</fieldset>
</form>
