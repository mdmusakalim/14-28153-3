
<html>
<body>

<form >
	<fieldset>
		<legend>BLOOD GROUP</legend>
		<select required>
  <option value="">None</option>
  <option value="A+">A+</option>
  <option value="A-">A-</option>
  <option value="B+">B+</option>
  <option value="B-">B-</option>
  <option value="O+">O+</option>
  <option value="O-">O-</option>
  <option value="AB+">AB+</option>
  <option value="AB-">AB-</option>
</select>
<br/><br/>
<hr/>
		<input type="submit" name="submit" value="Submit" >
		
	</fieldset>
</form>

</body>
</html>